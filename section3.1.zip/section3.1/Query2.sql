create table `databasetest`.`cinema`(
`id` INT NOT NULL AUTO_INCREMENT,
`movie` VARCHAR(32) NOT NULL,
`description` VARCHAR(32) NOT NULL,
`rating` float(10,2) NOT NULL,
PRIMARY KEY(`id`) 
);

insert into `databasetest`.`cinema`(`movie`,`description`,`rating`) values(
'War' ,'great 3D', 8.9);
insert into `databasetest`.`cinema`(`movie`,`description`,`rating`) values(
'Science' ,'Fiction', 8.5);
insert into `databasetest`.`cinema`(`movie`,`description`,`rating`) values(
'Irish' ,'Boring', 6.2);
insert into `databasetest`.`cinema`(`movie`,`description`,`rating`) values(
'Ice Song' ,'Fantacy', 8.6);
insert into `databasetest`.`cinema`(`movie`,`description`,`rating`) values(
'House card' ,'interesting', 9.1);

select * from `databasetest`.`cinema`
where mod(id,2)!=0 and description != 'boring'
order by rating desc;