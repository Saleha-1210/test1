create table `databasetest`.`customers`(
`id` INT NOT NULL AUTO_INCREMENT,
`name` VARCHAR(48) NOT NULL,
PRIMARY KEY(`id`)
);

create table `databasetest`.`order`(
`id` INT NOT NULL AUTO_INCREMENT,
`custId` INT NOT NULL,
FOREIGN KEY(`custId`) REFERENCES`databasetest`.`customers`(`id`),
primary key (`id`)
);

insert into `databasetest`.`customers`(`name`)values('Joe');
insert into `databasetest`.`customers`(`name`)values('Henry');
insert into `databasetest`.`customers`(`name`)values('Sam');
insert into `databasetest`.`customers`(`name`)values('Max');

insert into `databasetest`.`order`(`custId`)values(3);
insert into `databasetest`.`order`(`custId`)values(1);

select `name` from `databasetest`.`customers`
where `id` not in(select `custId` from `databasetest`.`order`);