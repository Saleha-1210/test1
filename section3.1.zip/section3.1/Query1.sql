create table `databasetest`.`employee`(`empId` INT NOT NULL AUTO_INCREMENT,
`empName` VARCHAR(48) NOT NULL,
`empDOB` DATE NOT NULL,
`gender` VARCHAR(8) NOT NULL,
`empJoiningDate` DATE NOT NULL,
`empPhoneNum` VARCHAR(16) NOT NULL,
`empSalary` DOUBLE NOT NULL,
PRIMARY KEY(`empId`));

create table `databasetest`.`department`(
`deptId` INT NOT NULL AUTO_INCREMENT,
`empId` INT NOT NULL,
`deptName` VARCHAR(48) NOT NULL,
`designation` VARCHAR(16) NOT NULL,
FOREIGN KEY(`empId`) REFERENCES `databasetest`.`employee`(`empId`),
PRIMARY KEY(`deptId`)
);

create table `databasetest`.`leave`(
`leaveId` INT NOT NULL AUTO_INCREMENT,
`empyId` INT NOT NULL,
`deptId` INT NOT NULL,
`leaveStart` DATE NOT NULL,
`leaveEnd` DATE NOT NULL,
`leaveType` VARCHAR(48) NOT NULL,
FOREIGN KEY(`empyId`) REFERENCES `databasetest`.`employee`(`empId`),
FOREIGN KEY(`deptId`) REFERENCES `databasetest`.`department`(`deptId`),
PRIMARY KEY(`leaveId`)

);