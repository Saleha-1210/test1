create table `databasetest`.`person`(
	`id` INT NOT NULL AUTO_INCREMENT,
    `email` VARCHAR(48) NOT NULL CHECK(`email` like lower(`email`)),
    primary key(`id`)

);
insert into `databasetest`.`person`(`email`) values(
'john@example.com');
insert into `databasetest`.`person`(`email`) values(
'bob@example.com');
insert into `databasetest`.`person`(`email`) values(
'john@example.COM');

delete from `databasetest`.`person` where id not in (select * from (select min(id)
 from `databasetest`.`person` group by email) as p);
 
select * from `databasetest`.`person`;
