create table `databasetest`.`salary`(
`id` INT NOT NULL AUTO_INCREMENT,
`name` VARCHAR(32) NOT NULL,
`sex` ENUM('f','m') NOT NULL,
`salary` INT NOT NULL,
PRIMARY KEY(`id`)
);

insert into `databasetest`.`salary`(`name`,`sex`,`salary`) values('A','m',2500);
insert into `databasetest`.`salary`(`name`,`sex`,`salary`) values('B','f',1500);
insert into `databasetest`.`salary`(`name`,`sex`,`salary`) values('C','m',5500);
insert into `databasetest`.`salary`(`name`,`sex`,`salary`) values('D','f',500);

update `databasetest`.`salary`
set sex = if(sex = 'm','f','m');