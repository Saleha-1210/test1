create table `databasetest`.`idextable` (
`id` INT NOT NULL AUTO_INCREMENT,
`email` varchar(48),
primary key(`id`)
);

CREATE INDEX index_name
ON `databasetest`.`idextable`(`email`);

SHOW INDEX FROM `databasetest`.`idextable`;