create schema `student`;

create table `student`.`semesterMaster`(
`id` INT NOT NULL AUTO_INCREMENT,
`semNo` INT NOT NULL,
primary key(`id`)
);

create table `student`.`subjectMaster`(
`id` INT NOT NULL AUTO_INCREMENT,
`subName` VARCHAR(48) NOT NULL,
primary key(`id`)
);

create table `student`.`studentGrades`(
`rollNo` INT NOT NULL,
`name` VARCHAR(48) NOT NULL,
`dob` DATE NOT NULL,
`subjectId` INT NOT NULL,
`semId` INT NOT NULL,
`grade` varchar(8) NOT NULL,
FOREIGN KEY(`subjectId`) REFERENCES `student`.`subjectMaster`(`id`),
FOREIGN KEY(`semId`) REFERENCES `student`.`semesterMaster`(`id`),
PRIMARY KEY(`rollNo`)
);
 

 
 
 
 
 
 
 