create table `databasetest`.`person1`(
`id` INT NOT NULL AUTO_INCREMENT,
`firstName` varchar(48) NOT NULL,
`lastName` varchar(48) NOT NULL,
primary key(`id`)
);

create table `databasetest`.`address`(
`addId` INT NOT NULL AUTO_INCREMENT,
`personId` INT NOT NULL,
`city` VARCHAR(36) NOT NULL,
`state` VARCHAR(36) NOT NULL,
FOREIGN KEY(`personId`) REFERENCES `databasetest`.`person1` (`id`),
PRIMARY KEY(`addId`)
);

insert into `databasetest`.`person1` (`firstName`,`lastName`)values('Wang','Allen');
insert into `databasetest`.`person1` (`firstName`,`lastName`)values('Alice','Bob');
insert into `databasetest`.`person1` (`firstName`,`lastName`)values('Saleha','Shaikh');

insert into `databasetest`.`address` (`personId`,`city`,`state`)values(1,'New York City','New York');
insert into `databasetest`.`address` (`personId`,`city`,`state`)values(2,'LeetCode','California');

select `person1`.`id`,`person1`.`firstName`,`person1`.`lastName`,`address`.`city`,`address`.`state` from `databasetest`.`person1` 
LEFT JOIN `databasetest`.`address` ON `databasetest`.`person1`.`id` = `databasetest`.`address`.`personId`;

