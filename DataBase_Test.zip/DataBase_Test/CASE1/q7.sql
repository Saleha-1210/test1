-- 7. Retrieve the name of a chef who prepares more recipes than any 
-- other chef.
select `Name` ,count(`chefId`) as TotalRecipies
from `database_test`.`chef_master`
inner join `database_test`.`item_chef`
where `database_test`.`item_chef`.`chefId` = `database_test`.`chef_master`.`id`
group by(`chefId`)
order by TotalRecipies desc
limit 1
