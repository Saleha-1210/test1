-- 5. List out total order placed by each User.
select `firstName`,count(`uId`) AS TotalOrderPlaced
from `database_test`.`order`
where `order`.`status` =1
group by(`uId`)
