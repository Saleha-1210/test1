-- 3. List of all menus with its menu items.
select `database_test`.`menu`.`title`,`database_test`.`item`.`title`
from `database_test`.`menu`,`database_test`.`item`
inner join `database_test`.`menu_item`
where `database_test`.`menu`.`id` = `database_test`.`menu_item`.`menuId` AND `database_test`.`menu_item`.`thingId` = `database_test`.`item`.`id`

