-- 9. List out user along with the average amount spend at the 
-- restaurant.
select `firstName`,format (avg(`subToal`),2) as AvgAmountSpent
from `database_test`.`order`
group by(`uId`)