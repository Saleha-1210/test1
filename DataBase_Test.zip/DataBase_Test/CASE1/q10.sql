-- 10. List out the menu items which are preferred by the 
-- customer at dinner time.
 select `title` as MenuItems
 from `database_test`.`item`
 inner join `database_test`.`order_item`,`database_test`.`menu_item`
 where `database_test`.`order_item`.`itmId` = `database_test`.`item`.`id` and
       cast(`database_test`.`order_item`.`createdAt` as time) >= '20:12:53'
       group by(`title`)
