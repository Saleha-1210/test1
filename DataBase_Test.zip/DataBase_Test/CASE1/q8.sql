-- 8. Retrieve the amount of subtotal for all day on 9th November 
-- 2021. (It does not include the total, formula: item price * 
-- ordered qty).
select sum(`database_test`.`order_item`.`quantity` * `database_test`.`item`.`price`) as SubToal
from `database_test`.`order_item`,`database_test`.`item`
where `database_test`.`item`.`id` = `database_test`.`order_item`.`itmId` AND CAST(`database_test`.`order_item`.`createdAt` AS DATE) ='2021-11-09';