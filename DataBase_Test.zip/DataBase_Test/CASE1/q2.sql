-- 2. Customer who visited the restaurant more than twice.
select `firstName`,`lastName`
from `database_test`.`booking`
group by(`usersId`)
having count(`usersId`) >=2 














