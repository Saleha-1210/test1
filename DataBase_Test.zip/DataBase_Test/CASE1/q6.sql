-- 6. Make a list of each user and the highest-priced menu item he 
-- or she ordered.
select `database_test`.`order`.`firstName`,max(`database_test`.`item`.`price`) as MaximumPrice 
from `database_test`.`order`,`database_test`.`item`
inner join `database_test`.`order_item`
where `database_test`.`order_item`.`itmId` = `database_test`.`item`.`id` and `database_test`.`order_item`.`ordId` = `database_test`.`order`.`id`
group by(`firstName`)

