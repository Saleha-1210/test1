-- 1. Total income of Restaurant till now.
select sum(`grandTotal`)
 from `database_test`.`order`

