-- 3. List out all the polls which are currently active
select `title`
from `datatest_case2`.`poll`
inner join `datatest_case2`.`poll_answer`
where `poll_answer`.`active` = 1
group by(`title`)