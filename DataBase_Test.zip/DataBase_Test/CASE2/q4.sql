-- 4 . List out all the users who is not logged in since last week.
select`firstName` 
from `datatest_case2`.`user`
where datediff(`lastLogin`,curdate()) >= -7

