-- 5. List out all the users whose email provider is not goggle

select `firstName` as UserName
from `datatest_case2`.`user`
where (SUBSTRING_INDEX(SUBSTR(`datatest_case2`.`user`.`email`, INSTR(`datatest_case2`.`user`.`email`, '@') + 1),'.',1))   != 'gmail'