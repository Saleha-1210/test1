-- 2. List out all the categories which is having multiple poll 
-- questions under it.
select `title`
from `datatest_case2`.`category` 
inner join `datatest_case2`.`poll_category` as t1,`datatest_case2`.`poll_question`
where t1.`categoryId` = `datatest_case2`.`category` .`id`
having count(`datatest_case2`.`poll_question`.`pollId`) >1