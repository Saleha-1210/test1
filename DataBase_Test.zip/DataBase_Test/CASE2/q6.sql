-- 6. List out all the polls which are published in 2021.
select `title`
from `datatest_case2`.`poll` 
where EXTRACT(YEAR FROM `datatest_case2`.`poll`.`createdAt`)='2021'