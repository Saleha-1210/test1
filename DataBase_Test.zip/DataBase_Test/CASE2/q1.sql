-- 1. List out all questions with it’s answer which is having 
-- maximum vote.
select `datatest_case2`.`poll_question`.`type` as Question , `datatest_case2`.`poll_answer`.`content` as Answer
from `datatest_case2`.`poll_question`,`datatest_case2`.`poll_answer`
inner join `datatest_case2`.`poll_vote` as t1
where t1.`queId` =  `datatest_case2`.`poll_question`.`id` and 
 t1.`answerId` = `datatest_case2`.`poll_answer`.`id`
 group by(`queId`)
 order by (count(`pollId3`)) desc
 limit 1


