-- 7. List out all the users who did not answer any poll yet
select `datatest_case2`.`user`.`id`,`firstName`
from `datatest_case2`.`user`
inner join `datatest_case2`.`poll_vote` 
where `datatest_case2`.`user`.`id` not in(select `userId2` from `datatest_case2`.`poll_vote`)
group by(`firstName`)
