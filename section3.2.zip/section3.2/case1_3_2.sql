create table `section3.2`.`activity`(
	`playerId` INT NOT NULL,
    `deviceId` INT NOT NULL,
    `eventDate` DATE NOT NULL,
    `gamesPlayed` INT NOT NULL,
    primary key(`playerId`,`eventDate`)
);

insert into `section3.2`.`activity`(`playerId`,`deviceId`,`eventDate`,`gamesPlayed`) values(1,2,'2016-03-01',5);
insert into `section3.2`.`activity`(`playerId`,`deviceId`,`eventDate`,`gamesPlayed`) values(1,2,'2016-05-02',6);
insert into `section3.2`.`activity`(`playerId`,`deviceId`,`eventDate`,`gamesPlayed`) values(2,3,'2017-06-25',1);
insert into `section3.2`.`activity`(`playerId`,`deviceId`,`eventDate`,`gamesPlayed`) values(3,1,'2016-03-02',0);
insert into `section3.2`.`activity`(`playerId`,`deviceId`,`eventDate`,`gamesPlayed`) values(3,4,'2018-07-03',5);



select `activity`.`playerId` , min(`activity`.`eventDate`)
from `section3.2`.`activity`
group by `activity`.`playerId`;

select `activity`.`playerId` ,`activity`.`deviceId`, min(`activity`.`eventDate`)
from `section3.2`.`activity`
group by `activity`.`playerId`;

select a.playerId, a.deviceId
from `section3.2`.`activity` a JOIN
(select playerId, min(eventDate) 'first_login'
from `section3.2`.`activity` group by playerId) t
ON a.playerId=t.playerId and a.eventDate = t.first_login;





