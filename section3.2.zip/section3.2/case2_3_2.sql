create table `section3.2`.`courses` (
`student` VARCHAR(48) NOT NULL,
`class` VARCHAR(48) NOT NULL,
primary key(`student`,`class`)
);
insert into `section3.2`.`courses`(`student`,`class`) values('A','Math');
insert into `section3.2`.`courses`(`student`,`class`) values('B','English');
insert into `section3.2`.`courses`(`student`,`class`) values('C','Math');
insert into `section3.2`.`courses`(`student`,`class`) values('D','Biology');
insert into `section3.2`.`courses`(`student`,`class`) values('E','Math');
insert into `section3.2`.`courses`(`student`,`class`) values('F','Computer');
insert into `section3.2`.`courses`(`student`,`class`) values('G','Math');
insert into `section3.2`.`courses`(`student`,`class`) values('H','Math');
insert into `section3.2`.`courses`(`student`,`class`) values('I','Math');

select `courses`.`class`
from `section3.2`.`courses`
group by class having count(distinct student) >=5;
