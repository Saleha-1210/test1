create table `section3.2`.`world`(
`name` VARCHAR(24) NOT NULL,
`continent` VARCHAR(24) NOT NULL,
`area` double NOT NULL,
`population` INT NOT NULL,
`gdp` double NOT NULL,
primary key(`name`)
);

insert into `section3.2`.`world`(`name`,`continent`,`area`,`population`,`gdp`)values('Afghanistan','Asia',652230,25500100,20343000000);
insert into `section3.2`.`world`(`name`,`continent`,`area`,`population`,`gdp`)values('Albania','Europe',28748,2831741,12960000000);
insert into `section3.2`.`world`(`name`,`continent`,`area`,`population`,`gdp`)values('Algeria','Africa',2381741,37100000,188681000000);
insert into `section3.2`.`world`(`name`,`continent`,`area`,`population`,`gdp`)values('Andorra','Europe',468,78115,3712000000);
insert into `section3.2`.`world`(`name`,`continent`,`area`,`population`,`gdp`)values('Angola','Africa',1246700,20609294,100990000000);

select `world`.`name`,`world`.`population`,`world`.`area`
from `section3.2`.`world`
where `world`.`area` >=3000000 or `world`.`population` >=25000000;
